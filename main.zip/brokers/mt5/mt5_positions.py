"""
MT5 account and position queries.
Each public method calls client.ensure_connected() first so the system
recovers automatically if the terminal was restarted.
"""

from __future__ import annotations

import logging
from typing import List, Optional

from brokers.mt5.mt5_client import Mt5Client
from brokers.mt5.mt5_types import Mt5PositionType
from interfaces.position import AccountInfo, Position, PositionSide, SymbolInfo
from datetime import datetime, timezone, timedelta

logger = logging.getLogger(__name__)


class Mt5Positions:
    def __init__(self, client: Mt5Client) -> None:
        self._client = client

    @property
    def _mt5(self):
        return self._client.mt5

    # ── Account ───────────────────────────────────────────────────────────

    def get_account_info(self) -> AccountInfo:
        self._client.ensure_connected()
        info = self._mt5.account_info()
        if info is None:
            error = self._mt5.last_error()
            raise RuntimeError(f"account_info() failed: {error}")

        return AccountInfo(
            login=info.login,
            server=info.server,
            currency=info.currency,
            balance=info.balance,
            equity=info.equity,
            margin=info.margin,
            free_margin=info.margin_free,
            margin_level=info.margin_level,
            leverage=info.leverage,
        )

    # ── Symbol ────────────────────────────────────────────────────────────

    def get_symbol_info(self, symbol: str) -> SymbolInfo:
        self._client.ensure_connected()
        info = self._mt5.symbol_info(symbol)
        if info is None:
            error = self._mt5.last_error()
            raise RuntimeError(f"symbol_info({symbol!r}) failed: {error}")

        if not info.visible:
            self._mt5.symbol_select(symbol, True)
            info = self._mt5.symbol_info(symbol)

        tick = self._mt5.symbol_info_tick(symbol)
        ask = tick.ask if tick else 0.0
        bid = tick.bid if tick else 0.0

        return SymbolInfo(
            # Identity
            symbol=info.name,
            description=info.description,
            currency_base=info.currency_base,
            currency_profit=info.currency_profit,
            currency_margin=info.currency_margin,
            # Price precision
            digits=info.digits,
            point=info.point,
            tick_size=info.trade_tick_size,
            tick_value=info.trade_tick_value,
            # Contract
            contract_size=info.trade_contract_size,
            lot_min=info.volume_min,
            lot_max=info.volume_max,
            lot_step=info.volume_step,
            # Quote
            ask=ask,
            bid=bid,
            spread=info.spread,
            spread_float=bool(info.spread_float),
            # Margin
            margin_initial=info.margin_initial,
            margin_maintenance=info.margin_maintenance,
            margin_hedged=info.margin_hedged,
            # Execution
            filling_mode=info.filling_mode,
            execution_mode=info.trade_exemode,
            trade_mode=info.trade_mode,
            # Swap
            swap_mode=info.swap_mode,
            swap_long=info.swap_long,
            swap_short=info.swap_short,
            swap_rollover3days=info.swap_rollover3days,
            # Stops
            stops_level=info.trade_stops_level,
            freeze_level=info.trade_freeze_level,
            # Volume (redundant with lot_* but kept for clarity)
            volume_min=info.volume_min,
            volume_max=info.volume_max,
            volume_step=info.volume_step,
            # Optional
            expiration_mode=info.expiration_mode,
            order_mode=info.order_mode,
        )

    # ── Positions ─────────────────────────────────────────────────────────

    def get_open_positions(self, magic: Optional[int] = None) -> List[Position]:
        self._client.ensure_connected()
        raw = self._mt5.positions_get() or []
        if magic is not None:
            raw = [p for p in raw if p.magic == magic]

        return [
            Position(
                ticket=p.ticket,
                symbol=p.symbol,
                side=(
                    PositionSide.BUY
                    if p.type == Mt5PositionType.BUY
                    else PositionSide.SELL
                ),
                lots=p.volume,
                open_price=p.price_open,
                current_price=p.price_current,
                stop_loss=p.sl,
                take_profit=p.tp,
                swap=p.swap,
                profit=p.profit,
                open_time=int(p.time * 1000),
                comment=p.comment,
                magic=p.magic,
            )
            for p in raw
        ]

    def get_position_by_ticket(self, ticket: int) -> Optional[Position]:
        positions = self.get_open_positions()
        return next((p for p in positions if p.ticket == ticket), None)

    def get_daily_loss_pct(self, magic: int) -> float:
        self._client.ensure_connected()
        try:
            offset_hours = self._client.broker_utc_offset_hours
            now_utc = datetime.now(timezone.utc)
            now_broker = (now_utc + timedelta(hours=offset_hours)).replace(tzinfo=None)
            from_dt = datetime(
                now_broker.year, now_broker.month, now_broker.day, 0, 0, 0
            )
            to_dt = from_dt + timedelta(days=1)

            deals = self._mt5.history_deals_get(from_dt, to_dt) or []

            daily_pnl = sum(
                d.profit + d.swap + d.commission
                for d in deals
                if d.magic == magic and d.entry == self._client.mt5.DEAL_ENTRY_OUT
            )
            balance_ops = sum(
                d.profit for d in deals if d.type == self._client.mt5.DEAL_TYPE_BALANCE
            )

            if daily_pnl >= 0:
                return 0.0

            account = self._mt5.account_info()
            if not account or account.balance <= 0:
                return 0.0

            starting_balance = account.balance - daily_pnl - balance_ops
            if starting_balance <= 0:
                return 0.0

            return (abs(daily_pnl) / starting_balance) * 100

        except Exception:
            logger.warning(
                "Mt5Positions.get_daily_loss_pct: failed to calculate daily loss"
            )
            return 0.0

    def get_current_tick(self, symbol: str):
        self._client.ensure_connected()
        return self._mt5.symbol_info_tick(symbol)
